import java.util.Scanner;

public class Poligono {

	
	public static void main(String[] args) {

	    int lado1 = 0, lado2 = 0, lado3 = 0, lados = 0;
	    int opcao = 1;
	    int perimetro;
	   

	    while (opcao == 1) {
	        Scanner s = new Scanner(System.in);

	        
	        System.out.println("Quantos lados possui");
	        lados = s.nextInt();
	        
	        
	        System.out.println("Entre com o primeiro lado:");
	        lado1 = s.nextInt();
	        System.out.println("------------------------------------------------");
	        System.out.println("Entre com o segundo lado:");
	        lado2 = s.nextInt();
	        System.out.println("------------------------------------------------");
	        System.out.println("Entre com terceiro lado:");
	        lado3 = s.nextInt();
	        System.out.println("------------------------------------------------");
	        if (lados < 4) {
	        if ((lado1 < lado2 + lado3) && (lado2 < lado1 + lado3) && (lado3 < lado1 + lado2) && (lados <4)) {
	            if (lado1 == lado2 && lado1 == lado3) {
	                System.out.println("Triangulo Equilatero");
	            } else if ((lado1 == lado2) || (lado1 == lado3)) {
	                System.out.println("Triangulo Isosceles");
	            } else
	                System.out.println("Tri�ngulo Escaleno");
	        } else if ((lado1 == lado2) && (lado2==lado3) && (lados==4)) {
	            System.out.println("� quadrado!");
	        }
	        }else{ 
	        	System.out.println("Tem quatro lados");
	        }
	        
	        
	        perimetro=lado1+lado2+lado3;
	        System.out.println("O perimetro �   " + perimetro);
	        
	        
	        System.out.println("------------------------------------------------");
	        System.out.println("Deseja continuar? 1 = sim, 2 = n�o");
	        opcao = s.nextInt();
	        System.out.println("------------------------------------------------");
	    }
	    System.out.println("Tchau!");
	}
	
	}
	



