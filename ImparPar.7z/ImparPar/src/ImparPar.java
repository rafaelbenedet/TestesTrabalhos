import java.util.Scanner;

public class ImparPar {

	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		  
		int val1;
		int val2;
		int n;
		  
		  
		  
		  System.out.println("Digite o primeiro numero:");
		  val1 = scan.nextInt();
		  
		  System.out.println("Digite o segundo numero:");
		  val2 = scan.nextInt();
		  
		  n = val1*val2;
		  
		  if(n%2 == 0){
		   System.out.println("Numero � Par");
		  }
		  
		  else if(n%2 == 1){
		   System.out.println("Numero � Impar");
		  }

		  
		  if(n >10){
	        	System.out.println(n);
	        }else if(n <=10){ 
	        	n=n+10;
	        	System.out.println(n);
	        }else{ 
	        	n=val1+val2;
	        }
		 if (n >5) {
			 n=n+5;
			 System.out.println(n);
		 }else {
			 System.out.println(n);
		
			}
	}

}

